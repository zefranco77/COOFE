// Inicialização do bot Discord
console.log('Bot online!');