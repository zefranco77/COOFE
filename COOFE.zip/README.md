# COOFE

Bot de moderação robusto com painel web e status integrado.

## Comandos
- /ban
- /kick
- /mute
- /unmute
- /warn
- /warnings
- /clear
- /lockdown
- /unlock

## Como usar
1. Configure o `.env`
2. Rode `npm install`
3. Rode `node bot/index.js` e `node web/app.js`