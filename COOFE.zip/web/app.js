// Inicialização do painel web
console.log('Painel web iniciado');